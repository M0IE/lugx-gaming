document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const gameId = urlParams.get('id');

    if (gameId) {
        fetch(`fetch_game_details.php?id=${gameId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error en la red');
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    console.error(data.error);
                    return;
                }

                // Rellenar los elementos en la plantilla con los datos del juego
                document.getElementById('product-title').innerText = data.name;
                document.getElementById('product-image').src = data.image;
                document.getElementById('product-price').innerHTML = `<em>$${data.price}</em> $${data.discountedPrice}`;
                document.getElementById('product-description').innerText = data.description;
                document.getElementById('product-id').innerText = data.id;
                // Rellenar géneros y etiquetas si es necesario
            })
            .catch(error => console.error('Error al cargar los detalles del juego:', error));
    } else {
        console.error('No se proporcionó un ID de juego.');
    }
});
