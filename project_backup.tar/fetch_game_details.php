<?php
header('Content-Type: application/json');

// Conectar a la base de datos
$servername = "localhost";
$username = "username"; // Cambia esto por tu nombre de usuario
$password = "password"; // Cambia esto por tu contraseña
$dbname = "database"; // Cambia esto por el nombre de tu base de datos

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die(json_encode(['error' => 'Error de conexión a la base de datos']));
}

// Obtener el ID del juego
$gameId = isset($_GET['id']) ? $_GET['id'] : '';

if ($gameId) {
    // Preparar la consulta
    $stmt = $conn->prepare("SELECT * FROM games WHERE gameId = ?");
    $stmt->bind_param("s", $gameId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Obtener los datos del juego
        $game = $result->fetch_assoc();
        echo json_encode($game);
    } else {
        echo json_encode(['error' => 'Juego no encontrado']);
    }

    $stmt->close();
} else {
    echo json_encode(['error' => 'ID de juego no proporcionado']);
}

$conn->close();
?>
