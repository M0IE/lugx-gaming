-- SQL script to create the database and populate it with game and user data

CREATE DATABASE IF NOT EXISTS lugx_gaming;

USE lugx_gaming;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL
);

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    description TEXT,
    price DECIMAL(10, 2),
    original_price DECIMAL(10, 2),
    image VARCHAR(255),
    category VARCHAR(50),
    gameId VARCHAR(50)
);

-- Insert categories
INSERT INTO categories (name) VALUES
('Action'),
('Strategy'),
('Racing'),
('Adventure');

-- Insert game data
INSERT INTO products (name, description, price, original_price, image, category, gameId) VALUES
('Assassin\'s Creed Valhalla', 'Assassin\'s Creed Valhalla es un videojuego desarrollado por Ubisoft Montreal y publicado por Ubisoft. Es el duodécimo en importancia y el vigesimosegundo título de la saga Assassin\'s Creed, y sucesor al juego del 2018 Assassin\'s Creed Odyssey.', 24, 36, 'assets/images/trending-01.jpg', 'Action', 'AC-VAL'),
('Age of Empires IV', 'Age of Empires IV es un videojuego de estrategia en tiempo real desarrollado por Relic Entertainment en asociación con World\'s Edge y publicado por Xbox Game Studios. Es la cuarta entrega de la serie Age of Empires.', 22, 32, 'assets/images/trending-02.jpg', 'Strategy', 'AOE-IV'),
('Need for Speed Heat', 'Need for Speed Heat es un videojuego de carreras desarrollado por Ghost Games y publicado por Electronic Arts para Microsoft Windows, PlayStation 4 y Xbox One. Es la vigésimo cuarta entrega de la serie Need for Speed y conmemora el 25 aniversario de la serie.', 30, 45, 'assets/images/trending-03.jpg', 'Racing', 'NFS-HEAT'),
('Warcraft III: Reforged', 'Warcraft III: Reforged es un videojuego de estrategia en tiempo real desarrollado y publicado por Blizzard Entertainment. Es una remasterización del juego de 2002 Warcraft III: Reign of Chaos y su expansión The Frozen Throne.', 22, 32, 'assets/images/trending-04.jpg', 'Strategy', 'WC3-RF'),
('Gran Turismo 7', 'Gran Turismo 7 es un videojuego de simulación de carreras desarrollado por Polyphony Digital y publicado por Sony Interactive Entertainment. Es la octava entrega principal de la serie Gran Turismo.', 26, 38, 'assets/images/trending-03.jpg', 'Racing', 'GT-7'),
('Tomb Raider', 'Tomb Raider es un videojuego de acción-aventura desarrollado por Crystal Dynamics y publicado por Square Enix. Es un reinicio de la franquicia Tomb Raider y cuenta los orígenes de Lara Croft.', 20, 30, 'assets/images/trending-01.jpg', 'Adventure', 'TR-2013'),
('Command & Conquer Remastered', 'Command & Conquer Remastered Collection es un videojuego de estrategia en tiempo real desarrollado por Petroglyph Games y publicado por Electronic Arts. Es una remasterización de Command & Conquer y Red Alert.', 22, 32, 'assets/images/trending-04.jpg', 'Strategy', 'CC-REM'),
('Uncharted 4', 'Uncharted 4: A Thief\'s End es un videojuego de acción-aventura desarrollado por Naughty Dog y publicado por Sony Computer Entertainment. Es la cuarta entrega de la serie Uncharted.', 22, 32, 'assets/images/trending-02.jpg', 'Adventure', 'UC-4'),
('Call of Duty®: Modern Warfare® II', 'LUGX Gaming Template is based on the latest Bootstrap 5 CSS framework. This template is provided by TemplateMo and it is suitable for your gaming shop ecommerce websites. Feel free to use this for any purpose. Thank you.', 22, 28, 'assets/images/single-game.jpg', 'Action', 'COD MMII');

-- Add more games as needed for each section
