// Base de datos de productos (en una aplicación real, esto vendría de un servidor)
const products = {
    "product1": {
        id: "product1",
        name: "Assassin's Creed Valhalla",
        price: 24,
        originalPrice: 36,
        image: "assets/images/trending-01.jpg",
        description: "Assassin's Creed Valhalla es un videojuego desarrollado por Ubisoft Montreal y publicado por Ubisoft. Es el duodécimo en importancia y el vigesimosegundo título de la saga Assassin's Creed, y sucesor al juego del 2018 Assassin's Creed Odyssey.",
        category: "Action",
        gameId: "AC-VAL"
    },
    "product2": {
        id: "product2",
        name: "Age of Empires IV",
        price: 22,
        originalPrice: 32,
        image: "assets/images/trending-02.jpg",
        description: "Age of Empires IV es un videojuego de estrategia en tiempo real desarrollado por Relic Entertainment en asociación con World's Edge y publicado por Xbox Game Studios. Es la cuarta entrega de la serie Age of Empires.",
        category: "Strategy",
        gameId: "AOE-IV"
    },
    "product3": {
        id: "product3",
        name: "Need for Speed Heat",
        price: 30,
        originalPrice: 45,
        image: "assets/images/trending-03.jpg",
        description: "Need for Speed Heat es un videojuego de carreras desarrollado por Ghost Games y publicado por Electronic Arts para Microsoft Windows, PlayStation 4 y Xbox One. Es la vigésimo cuarta entrega de la serie Need for Speed y conmemora el 25 aniversario de la serie.",
        category: "Racing",
        gameId: "NFS-HEAT"
    },
    "product4": {
        id: "product4",
        name: "Warcraft III: Reforged",
        price: 22,
        originalPrice: 32,
        image: "assets/images/trending-04.jpg",
        description: "Warcraft III: Reforged es un videojuego de estrategia en tiempo real desarrollado y publicado por Blizzard Entertainment. Es una remasterización del juego de 2002 Warcraft III: Reign of Chaos y su expansión The Frozen Throne.",
        category: "Strategy",
        gameId: "WC3-RF"
    },
    "product5": {
        id: "product5",
        name: "Gran Turismo 7",
        price: 26,
        originalPrice: 38,
        image: "assets/images/trending-03.jpg",
        description: "Gran Turismo 7 es un videojuego de simulación de carreras desarrollado por Polyphony Digital y publicado por Sony Interactive Entertainment. Es la octava entrega principal de la serie Gran Turismo.",
        category: "Racing",
        gameId: "GT-7"
    },
    "product6": {
        id: "product6",
        name: "Tomb Raider",
        price: 20,
        originalPrice: 30,
        image: "assets/images/trending-01.jpg",
        description: "Tomb Raider es un videojuego de acción-aventura desarrollado por Crystal Dynamics y publicado por Square Enix. Es un reinicio de la franquicia Tomb Raider y cuenta los orígenes de Lara Croft.",
        category: "Adventure",
        gameId: "TR-2013"
    },
    "product7": {
        id: "product7",
        name: "Command & Conquer Remastered",
        price: 22,
        originalPrice: 32,
        image: "assets/images/trending-04.jpg",
        description: "Command & Conquer Remastered Collection es un videojuego de estrategia en tiempo real desarrollado por Petroglyph Games y publicado por Electronic Arts. Es una remasterización de Command & Conquer y Red Alert.",
        category: "Strategy",
        gameId: "CC-REM"
    },
    "product8": {
        id: "product8",
        name: "Uncharted 4",
        price: 22,
        originalPrice: 32,
        image: "assets/images/trending-02.jpg",
        description: "Uncharted 4: A Thief's End es un videojuego de acción-aventura desarrollado por Naughty Dog y publicado por Sony Computer Entertainment. Es la cuarta entrega de la serie Uncharted.",
        category: "Adventure",
        gameId: "UC-4"
    },
    "default": {
        id: "default",
        name: "Call of Duty®: Modern Warfare® II",
        price: 22,
        originalPrice: 28,
        image: "assets/images/single-game.jpg",
        description: "LUGX Gaming Template is based on the latest Bootstrap 5 CSS framework. This template is provided by TemplateMo and it is suitable for your gaming shop ecommerce websites. Feel free to use this for any purpose. Thank you.",
        category: "Action",
        gameId: "COD MMII"
    }
};

// Función para cargar los detalles del producto
function loadProductDetails() {
    // Obtener el ID del producto de la URL
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id') || 'default';
    
    // Obtener los detalles del producto
    const product = products[productId] || products['default'];
    
    // Actualizar la página con los detalles del producto
    document.getElementById('product-title').textContent = product.name;
    document.getElementById('breadcrumb-title').textContent = product.name;
    document.getElementById('product-name').textContent = product.name;
    document.getElementById('product-price').innerHTML = `<em>$${product.originalPrice}</em> $${product.price}`;
    document.getElementById('product-description').textContent = product.description;
    document.getElementById('product-image').src = product.image;
    document.getElementById('product-id').textContent = product.gameId;
    
    // Configurar el formulario para agregar al carrito
    const productForm = document.getElementById('product-form');
    if (productForm) {
        productForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const quantity = parseInt(document.getElementById('product-qty').value);
            
            // Agregar al carrito
            addToCart(product.id, product.name, product.price, product.image, quantity);
        });
    }
}

// Cargar los detalles del producto cuando se cargue la página
document.addEventListener('DOMContentLoaded', loadProductDetails);
