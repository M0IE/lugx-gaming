// Función para verificar si el usuario está logueado
function isLoggedIn() {
    return localStorage.getItem('currentUser') !== null;
}

// Función para actualizar el enlace de autenticación
function updateAuthLink() {
    const authLink = document.getElementById('auth-link');
    if (authLink) {
        if (isLoggedIn()) {
            const user = JSON.parse(localStorage.getItem('currentUser'));
            authLink.innerHTML = `<i class="fa fa-user"></i> ${user.name}`;
            authLink.href = "#";
            authLink.onclick = function(e) {
                e.preventDefault();
                showUserMenu();
            };
        } else {
            authLink.innerHTML = "Sign In";
            authLink.href = "login.html";
            authLink.onclick = null;
        }
    }
}

// Función para mostrar el menú de usuario
function showUserMenu() {
    // Verificar si el menú ya existe
    let userMenu = document.getElementById('user-dropdown');
    
    if (userMenu) {
        userMenu.remove();
        return;
    }
    
    const authLink = document.getElementById('auth-link');
    userMenu = document.createElement('div');
    userMenu.id = 'user-dropdown';
    userMenu.className = 'user-dropdown';
    userMenu.innerHTML = `
        <ul>
            <li><a href="#" id="logout-btn">Logout</a></li>
        </ul>
    `;
    
    // Estilizar el dropdown
    userMenu.style.position = 'absolute';
    userMenu.style.backgroundColor = '#fff';
    userMenu.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
    userMenu.style.borderRadius = '5px';
    userMenu.style.padding = '10px';
    userMenu.style.zIndex = '1000';
    
    // Posicionar el dropdown debajo del enlace de autenticación
    const rect = authLink.getBoundingClientRect();
    userMenu.style.top = (rect.bottom + window.scrollY) + 'px';
    userMenu.style.left = (rect.left + window.scrollX) + 'px';
    
    document.body.appendChild(userMenu);
    
    // Agregar evento al botón de logout
    document.getElementById('logout-btn').addEventListener('click', function(e) {
        e.preventDefault();
        logout();
    });
    
    // Cerrar dropdown al hacer clic fuera
    document.addEventListener('click', function closeDropdown(e) {
        if (e.target !== authLink && !userMenu.contains(e.target)) {
            userMenu.remove();
            document.removeEventListener('click', closeDropdown);
        }
    });
}

// Función para cerrar sesión
function logout() {
    localStorage.removeItem('currentUser');
    alert('Has cerrado sesión correctamente.');
    updateAuthLink();
    window.location.href = 'index.html';
}

// Función para registrar un nuevo usuario
function registerUser(name, email, password) {
    // Obtener usuarios existentes o inicializar array vacío
    let users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Verificar si el email ya existe
    if (users.some(user => user.email === email)) {
        return { success: false, message: 'El email ya está registrado' };
    }
    
    // Crear nuevo objeto de usuario
    const newUser = {
        id: Date.now().toString(),
        name: name,
        email: email,
        password: password // En una app real, deberías hashear la contraseña
    };
    
    // Agregar al array de usuarios
    users.push(newUser);
    
    // Guardar en localStorage
    localStorage.setItem('users', JSON.stringify(users));
    
    return { success: true };
}

// Función para iniciar sesión
function loginUser(email, password) {
    // Obtener usuarios de localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Buscar usuario con email y contraseña coincidentes
    const user = users.find(user => user.email === email && user.password === password);
    
    if (user) {
        // Almacenar usuario actual en localStorage (excluyendo la contraseña)
        const currentUser = {
            id: user.id,
            name: user.name,
            email: user.email
        };
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        return { success: true };
    } else {
        return { success: false, message: 'Email o contraseña incorrectos' };
    }
}

// Inicializar funcionalidad de autenticación cuando el DOM esté cargado
document.addEventListener('DOMContentLoaded', function() {
    // Actualizar enlace de autenticación
    updateAuthLink();
    
    // Actualizar contador del carrito
    updateCartCount();
    
    // Manejar envío del formulario de inicio de sesión
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            
            const result = loginUser(email, password);
            
            if (result.success) {
                window.location.href = 'index.html';
            } else {
                const errorElement = document.getElementById('login-error');
                errorElement.textContent = result.message;
                errorElement.style.display = 'block';
            }
        });
    }
    
    // Manejar envío del formulario de registro
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('register-name').value;
            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm-password').value;
            
            // Validar que las contraseñas coincidan
            if (password !== confirmPassword) {
                const errorElement = document.getElementById('register-error');
                errorElement.textContent = 'Las contraseñas no coinciden';
                errorElement.style.display = 'block';
                return;
            }
            
            const result = registerUser(name, email, password);
            
            if (result.success) {
                document.getElementById('register-success').style.display = 'block';
                document.getElementById('register-error').style.display = 'none';
                document.getElementById('register-form').reset();
                
                // Cambiar a la pestaña de inicio de sesión después del registro exitoso
                setTimeout(() => {
                    document.getElementById('login-tab').click();
                }, 1500);
            } else {
                const errorElement = document.getElementById('register-error');
                errorElement.textContent = result.message;
                errorElement.style.display = 'block';
                document.getElementById('register-success').style.display = 'none';
            }
        });
    }
});

// Función para actualizar el contador del carrito
function updateCartCount() {
    const cartCountElement = document.getElementById('cart-count');
    if (cartCountElement) {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        cartCountElement.textContent = totalItems;
    }
}
// Función para proteger páginas que requieren autenticación
function protectPage() {
    if (!isLoggedIn()) {
        alert('Debes iniciar sesión para acceder a esta página');
        window.location.href = 'login.html';
    }
}
