// Variables globales
let cart = [];

// Función para verificar si el usuario está autenticado
function isLoggedIn() {
    return localStorage.getItem('currentUser') !== null;
}

// Cargar el carrito desde localStorage
function loadCart() {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
    }
}

// Guardar el carrito en localStorage
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
}

// Actualizar el contador del carrito
function updateCartCount() {
    const cartCountElement = document.getElementById('cart-count');
    if (cartCountElement) {
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        cartCountElement.textContent = totalItems;
    }
}

// Agregar un producto al carrito
function addToCart(id, name, price, image, quantity = 1) {
    // Buscar si el producto ya está en el carrito
    const existingItemIndex = cart.findIndex(item => item.id === id);
    
    if (existingItemIndex !== -1) {
        // Si el producto ya está en el carrito, aumentar la cantidad
        cart[existingItemIndex].quantity += quantity;
    } else {
        // Si el producto no está en el carrito, agregarlo
        cart.push({
            id,
            name,
            price,
            image,
            quantity
        });
    }
    
    // Guardar el carrito y actualizar la interfaz
    saveCart();
    
    // Mostrar mensaje de confirmación
    alert(`${name} ha sido añadido al carrito.`);
}

// Actualizar la cantidad de un producto en el carrito
function updateCartItemQuantity(index, quantity) {
    if (index >= 0 && index < cart.length) {
        cart[index].quantity = quantity;
        saveCart();
        updateCartUI();
    }
}

// Eliminar un producto del carrito
function removeCartItem(index) {
    if (index >= 0 && index < cart.length) {
        cart.splice(index, 1);
        saveCart();
        updateCartUI();
    }
}

// Calcular el subtotal del carrito
function calculateSubtotal() {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

// Actualizar la interfaz del carrito
function updateCartUI() {
    const cartTableBody = document.getElementById('cart-table-body');
    const cartSubtotal = document.getElementById('cart-subtotal');
    const cartTotal = document.getElementById('cart-total');
    const emptyCartMessage = document.getElementById('empty-cart-message');
    const cartItems = document.getElementById('cart-items');
    
    if (!cartTableBody) return; // Si no estamos en la página del carrito, salir
    
    // Mostrar mensaje si el carrito está vacío
    if (cart.length === 0) {
        if (emptyCartMessage) emptyCartMessage.style.display = 'block';
        if (cartItems) cartItems.style.display = 'none';
        return;
    }
    
    // Ocultar mensaje de carrito vacío y mostrar los items
    if (emptyCartMessage) emptyCartMessage.style.display = 'none';
    if (cartItems) cartItems.style.display = 'block';
    
    // Limpiar la tabla
    cartTableBody.innerHTML = '';
    
    // Agregar cada producto a la tabla
    cart.forEach((item, index) => {
        const row = document.createElement('tr');
        const total = item.price * item.quantity;
        
        row.innerHTML = `
            <td>
                <div class="d-flex align-items-center">
                    <img src="${item.image}" alt="${item.name}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px; margin-right: 10px;">
                    <span>${item.name}</span>
                </div>
            </td>
            <td>$${item.price.toFixed(2)}</td>
            <td>
                <div class="quantity-controls">
                    <button class="quantity-btn decrease" data-index="${index}">-</button>
                    <input type="number" class="quantity-input" value="${item.quantity}" min="1" data-index="${index}">
                    <button class="quantity-btn increase" data-index="${index}">+</button>
                </div>
            </td>
            <td>$${total.toFixed(2)}</td>
            <td>
                <button class="remove-btn" data-index="${index}">
                    <i class="fa fa-trash"></i>
                </button>
            </td>
        `;
        
        cartTableBody.appendChild(row);
    });
    
    // Actualizar subtotal y total
    const subtotal = calculateSubtotal();
    const shipping = 5.00; // Costo fijo de envío
    const total = subtotal + shipping;
    
    if (cartSubtotal) cartSubtotal.textContent = `$${subtotal.toFixed(2)}`;
    if (cartTotal) cartTotal.textContent = `$${total.toFixed(2)}`;
    
    // Agregar eventos a los botones de cantidad y eliminar
    document.querySelectorAll('.quantity-btn.decrease').forEach(button => {
        button.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            if (cart[index].quantity > 1) {
                updateCartItemQuantity(index, cart[index].quantity - 1);
            }
        });
    });
    
    document.querySelectorAll('.quantity-btn.increase').forEach(button => {
        button.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            updateCartItemQuantity(index, cart[index].quantity + 1);
        });
    });
    
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', function() {
            const index = parseInt(this.getAttribute('data-index'));
            const quantity = parseInt(this.value);
            if (quantity > 0) {
                updateCartItemQuantity(index, quantity);
            } else {
                this.value = 1;
                updateCartItemQuantity(index, 1);
            }
        });
    });
    
    document.querySelectorAll('.remove-btn').forEach(button => {
        button.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            removeCartItem(index);
        });
    });
}

// Función para procesar la compra
function processCheckout() {
    if (!isLoggedIn()) {
        alert('Por favor inicia sesión para completar la compra');
        window.location.href = 'login.html';
        return;
    }
    
    // Verificar si hay productos en el carrito
    if (cart.length === 0) {
        alert('Tu carrito está vacío. Agrega productos antes de realizar la compra.');
        return;
    }
    
    // Obtener los juegos comprados anteriormente
    let purchasedGames = JSON.parse(localStorage.getItem('purchasedGames')) || [];
    
    // Agregar los juegos del carrito a los juegos comprados
    cart.forEach(item => {
        // Verificar si el juego ya está en la biblioteca
        const alreadyPurchased = purchasedGames.some(game => game.id === item.id);
        
        if (!alreadyPurchased) {
            purchasedGames.push({
                id: item.id,
                purchaseDate: new Date().toISOString()
            });
        }
    });
    
    // Guardar los juegos comprados
    localStorage.setItem('purchasedGames', JSON.stringify(purchasedGames));
    
    // Vaciar el carrito
    cart = [];
    saveCart();
    updateCartUI();
    
    // Mostrar mensaje de éxito
    alert('¡Gracias por tu compra! Los juegos han sido añadidos a tu biblioteca.');
    
    // Redirigir a la biblioteca
    window.location.href = 'library.html';
}

// Inicializar el carrito cuando se carga la página
document.addEventListener('DOMContentLoaded', function() {
    loadCart();
    updateCartCount();
    updateCartUI();
    
    // Agregar evento al botón de checkout
    const checkoutBtn = document.getElementById('checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            processCheckout();
        });
    }
    
    // Agregar eventos a los botones "Agregar al carrito" en la página de tienda
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const item = this.closest('.item');
            const id = item.getAttribute('data-id');
            const name = item.querySelector('.product-name').textContent;
            const priceText = item.querySelector('.price').textContent;
            const price = parseFloat(priceText.replace('$', ''));
            const image = item.querySelector('.thumb img').src;
            
            addToCart(id, name, price, image);
        });
    });
    
    // Agregar evento al formulario de producto en la página de detalles
    const productForm = document.getElementById('product-form');
    if (productForm) {
        productForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const productId = new URLSearchParams(window.location.search).get('id') || 'default';
            const productName = document.getElementById('product-name').textContent;
            const priceText = document.getElementById('product-price').textContent;
            const price = parseFloat(priceText.match(/\$(\d+(\.\d+)?)/)[1]);
            const image = document.getElementById('product-image').src;
            const quantity = parseInt(document.getElementById('product-qty').value);
            
            addToCart(productId, productName, price, image, quantity);
        });
    }
});
